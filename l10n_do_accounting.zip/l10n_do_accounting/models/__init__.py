from . import res_partner
from . import res_company
from . import l10n_latam_document_type
from . import account_journal
from . import account_move
from . import monkey_patch
from . import account_move_line
